#!/bin/bash
# ----------------------------------------------------------------------------------------------------\\
# Description:
#   A umbrella script for IBM Cloud Private post deployment on Amazon Web Services
# ----------------------------------------------------------------------------------------------------\\
#
# Author: joshisa(at)us.ibm.com (Sanjay Joshi)
#
# ----------------------------------------------------------------------------------------------------\\
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Licensed Materials - Property of IBM
#
# Copyright IBM Corp. 2018.
# ----------------------------------------------------------------------------------------------------\\
#

SCRIPTDIR=$PWD
clear
echo -e "\n"
echo -e "${tools}   Welcome to ${cloud} IBM Cloud Private (ICP) post-deployment on Amazon Web Services (AWS)"
echo -e "\n"
source ./00-variables.sh
cd $SCRIPTDIR
source ./remote-docker-login.sh
cd $SCRIPTDIR
source ./setup-kubectl.sh
cd $SCRIPTDIR
source ./setup-helm.sh
cd $SCRIPTDIR
source ./setup-etcdctl.sh
cd $SCRIPTDIR
source ./setup-calicoctl.sh
cd $SCRIPTDIR
# source ./setup-istioctl.sh
