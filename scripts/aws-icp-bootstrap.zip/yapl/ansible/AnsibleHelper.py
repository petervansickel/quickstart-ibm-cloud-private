"""
Created on Feb 2, 2019

@author: Peter Van Sickel

WARNING: Only the minimum support of Ansible commands has been implemented for ICP installation.

"""

import os, yaml
from subprocess import call
from yapl.utilities.Trace import Trace
from yapl.exceptions.Exceptions import MissingArgumentException
from yapl.exceptions.Exceptions import InvalidArgumentException


TR = Trace(__name__)


class AnsibleHelper(object):
  """
    Class to support running Ansible commands as defined by yaml command definitions.
  """

  def __init__(self):
    """
      Constructor
    """
    object.__init__(self)
  #endDef
  

  def createYamlFile(self, filePath, x):
    """
      Dump a yaml representation of the given object (x) to the given filePath. 
    """
    
    if (not filePath):
      raise MissingArgumentException("The file path (filePath) cannot be empty or None.")
    #endIf
    
    if (not x):
      raise MissingArgumentException("The object (x) to be dumped to the file cannot be empty or None.")
    #endIf
    
    destDirPath = os.path.dirname(filePath)
    
    if (not os.path.exists(destDirPath)):
      os.makedirs(destDirPath)
    #endIf
    
    with open(filePath, 'w') as yamlFile:
      yaml.dump(x,yamlFile,default_flow_style=False)
    #endWith
    
    return filePath
  #endDef
  

  def _invokeCommand(self,cmdList=[],cmdString=""):
    """
      Invoke a single command as specified by cmdList and cmdString
      
      Helper for invokeCommands()
    """
    methodName = "_invokeCommand"
    
    if (not cmdList):
      raise MissingArgumentException("A non-empty command list must be provided.")
    #endIf
    
    if (not cmdString):
      raise MissingArgumentException("A non-empty command string must be provided.")
    #endIf
    
    TR.info(methodName, "Invoking: %s" % cmdString)
    retcode = call(cmdList)
    if (retcode != 0):
      raise Exception("Invoking: '%s' Return code: %s" % (cmdString,retcode))
    #endIf

  #endDef
  
  
  def invokeCommands(self,cmdDocs,start,**kwargs):
    """
      Process command docs to invoke each command in sequence that is of kind ansible.  
      
      Processing of cmdDocs will stop as soon as a doc kind that is not ansible is encountered.
      
      All cmdDocs that are processed will be marked with a status attribute with the value PROCESSED.
       
      cmdDocs - a list of 1 or more YAML documents loaded from yaml.load_all()
      by the caller.
      
      start - index where to start processing in the cmdDocs list.
            
      For ansible commands, the first doc defines the command and a subsequent doc may be the definition
      of a playbook for an ansible-playbook command.  There may be multiple ansible command-playbook pairs 
      in the given cmdDocs list.
      
      kwargs for the AnsibleHelper may include the following:
        stagingDirPath - directory path where a yaml file is to be created to be used with an 
                         ansible-playbook command. 
    
      TODO - This method needs a refactoring to break out the processing of specific ansible commands
      and to handle the processing of flags and options in separate helper methods.
    """
    if (not cmdDocs):
      raise MissingArgumentException("A non-empty list of command documents (cmdDocs) must be provided.")
    #endIf
    
    # Start processing cmdDocs at the given start
    for i in range(start,len(cmdDocs)):
      doc = cmdDocs[i]
      
      status = doc.get('status')
      if (status and status == 'Processed'): continue
      
      kind = doc.get('kind')
      
      if (not kind or kind != 'ansible'): break # done
      
      command = doc.get('command','ansible')

      cmdStr = "%s" % command
      cmdList = [ command ]
      
      # Process flags - flags have no argument
      flags = doc.get('flags')
      if (flags):
        for flag in flags:
          if (len(flag) > 1):
            # multi-character flags get a double dash
            cmdList.append('--%s' % flag)
            cmdStr = "%s --%s" % (cmdStr,flag)
          else:
            # single character flags get a single dash
            cmdList.append('-%s' % flag)
            cmdStr = "%s -%s" % (cmdStr,flag)
          #endIf          
        #endFor
      #endIf
      
      # process options - options have an argument
      options = doc.get('options')
      if (options):
        optionNames = options.keys()
        for optionName in optionNames:
          optionValue = options.get(optionName)
          if (len(optionName) > 1):
            cmdList.append("--%s" % optionName)
            cmdStr = "%s --%s" % (cmdStr,optionName)
          else:
            cmdList.append("-%s" % optionName)
            cmdStr = "%s -%s" % (cmdStr,optionName)
          #endIf
          # TBD: special processing for other options goes here
          cmdList.append(optionValue)
          cmdStr = "%s %s" % (cmdStr,optionValue)
        #endFor
      #endIf

      if (command == 'ansible-playbook'):
        # Check that there is a next document in the cmdDocs
        # The next document is the yaml that gets dumped to a file the playbook
        if (len(cmdDocs) <= i+1):
          raise InvalidArgumentException("Processing document: %d. Expecting another document for the playbook in documents: %s ." % (i,cmdDocs))
        #endIf

        stagingDir = kwargs.get('stagingDirPath')
        if (not stagingDir):
          raise MissingArgumentException("The ansible-playbook command expects a staging directory path (stagingDirPath) keyword argument.")
        #endIf

        playbookFileName = doc.get('playbook')
        if (not playbookFileName):
          raise MissingArgumentException("The ansible-playbook command expects a playbook attribute in the command document: %s" % doc)
        #endIf
        
        playbookDoc = cmdDocs[i+1]
        
        kind = playbookDoc.get('kind')
        if (not kind or kind != 'playbook'):
          raise InvalidArgumentException("The ansible-playbook command expects a supporting document of kind playbook, but got:\n\t%s" % playbookDoc)
        #endIf
        
        playbook = playbookDoc.get('playbook')
        if (not playbook):
          raise InvalidArgumentException("The ansible-playbook command expects a supporting document with a playbook attribute, but got:\n\t%s" % playbookDoc)
        #endIf
        
        playbookFilePath = os.path.join(stagingDir,playbookFileName)
        
        self.createYamlFile(playbookFilePath,playbook)
        
        cmdList.append(playbookFilePath)
        cmdStr = "%s %s" % (cmdStr, playbookFilePath)
        playbookDoc['status'] = 'PROCESSED'
      #endIf
                    
      doc['status'] = 'PROCESSED'
      self._invokeCommand(cmdList=cmdList, cmdString=cmdStr)
    #endFor
    
  #endDef
  

#endClass