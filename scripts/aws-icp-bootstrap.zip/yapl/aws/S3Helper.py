"""
Created on Jan 2, 2019

@author: Peter Van Sickel - pvs@us.ibm.com

Description:
  Assist with various S3 operations and support methods using the boto3 Python library.
  
History:
  2 JAN 2019 Initial creation 
"""

class S3Helper(object):
  """
    Various methods that ease the use of the boto3 Python library for working with S3.
  """
  
  def __init__(self):
    """
      Constructor
    """
    object.__init__(self)
  #endDef
  
  
#endClass